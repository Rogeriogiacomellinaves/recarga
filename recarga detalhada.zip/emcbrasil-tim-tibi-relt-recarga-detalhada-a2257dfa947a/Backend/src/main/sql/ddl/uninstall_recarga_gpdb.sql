--=================================================================================================================
-- Projeto       : Recarga Detalhada
-- Responsavel   : José Victor Munhoz Oki | Marcus
-- Solicitante   : 
-- Funcao        : Script de desinstalação da estrutura das tabelas no GPDB
-- Criacao       : 26/10/2019
-- ================================================================================================================

--view reports.vw_r_recarga_oferta
drop view reports.vw_r_recarga_oferta;

-- ext.dw_r_recarga_oferta_dia
drop external table ext.dw_r_recarga_oferta_dia;

--ext.dw_r_recarga_oferta_hist
drop external table ext.dw_r_recarga_oferta_hist;

--ext.dw_r_recarga_oferta_relatorio_hist
drop external table ext.dw_r_recarga_oferta_relatorio_hist;

--ext.dw_r_recarga_oferta_relatorio_dia
drop external table ext.dw_r_recarga_oferta_relatorio_dia;

-- reports.dw_r_recarga_oferta_hist
drop table reports.dw_r_recarga_oferta_hist;

--reports.dw_r_recarga_oferta_dia
drop table reports.dw_r_recarga_oferta_dia;

--reports.dw_r_recarga_oferta_relatorio_hist
drop table reports.dw_r_recarga_oferta_relatorio_hist;

--reports.dw_r_recarga_oferta_relatorio_dia
drop table reports.dw_r_recarga_oferta_relatorio_dia;

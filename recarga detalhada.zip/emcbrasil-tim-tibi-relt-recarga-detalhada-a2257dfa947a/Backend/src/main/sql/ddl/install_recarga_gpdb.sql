--=================================================================================================================
-- Projeto       : Recarga Detalhada
-- Responsavel   : José Victor Munhoz Oki | Marcus
-- Solicitante   : 
-- Funcao        : Script de instalação da estrutura das tabelas no GPDB
-- Criacao       : 26/10/2019
-- ================================================================================================================

create external table ext.dw_r_recarga_oferta_dia
(
    dat_ref                 date                   ,
    num_hora                numeric                ,
    nom_regional_venda      character varying(100) ,
    num_cn                  character varying(10)  ,
    dsc_plano_normalizado   character varying(10)  ,
    dsc_valor_face          character varying(50)  ,
    nom_canal_venda         character varying(250) ,
    nom_fantasia            character varying(250) ,
    dsc_oferta_normalizada  character varying(50)  ,
    vlr_recarga             numeric                ,
    qtd_recarga             numeric                
)
location ('gphdfs://dcaisilon.timbrasil.com.br/platinum/work/recarga_detalhada/diario/gpdb_staging/*')
format 'text' (delimiter '|' null '' escape 'off') encoding 'utf8';

alter table ext.dw_r_recarga_oferta_dia owner to udbd_load;

create external table ext.dw_r_recarga_oferta_hist
(
    dat_ref                 date                   ,
    num_hora                numeric                ,
    nom_regional_venda      character varying(100) ,
    num_cn                  character varying(10)  ,
    dsc_plano_normalizado   character varying(10)  ,
    dsc_valor_face          character varying(50)  ,
    nom_canal_venda         character varying(250) ,
    nom_fantasia            character varying(250) ,
    dsc_oferta_normalizada  character varying(50)  ,
    vlr_recarga             numeric                ,
    qtd_recarga             numeric                
)
location ('gphdfs://dcaisilon.timbrasil.com.br/platinum/work/recarga_detalhada/historico/gpdb_staging/*')
format 'text' (delimiter '|' null '' escape 'off') encoding 'utf8';

alter table ext.dw_r_recarga_oferta_hist owner to udbd_load;

create table reports.dw_r_recarga_oferta_hist
(
    dat_ref                 date                   ,
    num_hora                numeric                ,
    nom_regional_venda      character varying(100) ,
    num_cn                  character varying(10)  ,
    dsc_plano_normalizado   character varying(10)  ,
    dsc_valor_face          character varying(50)  ,
    nom_canal_venda         character varying(250) ,
    nom_fantasia            character varying(250) ,
    dsc_oferta_normalizada  character varying(50)  ,
    vlr_recarga             numeric                ,
    qtd_recarga             numeric                
)
WITH (APPENDONLY=true, COMPRESSLEVEL=6, ORIENTATION=row, COMPRESSTYPE=zlib, OIDS=FALSE) DISTRIBUTED RANDOMLY
PARTITION BY RANGE(dat_ref) (
start (date '2019-06-01'::date) inclusive end (date '2019-10-26'::date) exclusive every (interval '1 day'),
default partition outlying_days  WITH (APPENDONLY=true, COMPRESSLEVEL=6, ORIENTATION=row, COMPRESSTYPE=zlib, OIDS=FALSE));

alter table reports.dw_r_recarga_oferta_hist owner to udbd_load;
grant select on table reports.dw_r_recarga_oferta_hist to sdx_bigdata;

comment on table reports.dw_r_recarga_oferta_hist is 'Tabela com dados da base de ofertas de recarga';

comment on column reports.dw_r_recarga_oferta_hist.dat_ref                is 'Data referência da recarga';
comment on column reports.dw_r_recarga_oferta_hist.num_hora               is 'Hora da recarga';
comment on column reports.dw_r_recarga_oferta_hist.nom_regional_venda     is 'Descrição do regional de venda.';
comment on column reports.dw_r_recarga_oferta_hist.num_cn                 is 'Código de área nacional';
comment on column reports.dw_r_recarga_oferta_hist.dsc_plano_normalizado  is 'Descrição  do plano com agrupamento para recargar';
comment on column reports.dw_r_recarga_oferta_hist.dsc_valor_face         is 'Valor de face das recargas.';
comment on column reports.dw_r_recarga_oferta_hist.nom_canal_venda        is 'Descrição do canal de venda.';
comment on column reports.dw_r_recarga_oferta_hist.nom_fantasia           is 'Nome fantasia.';
comment on column reports.dw_r_recarga_oferta_hist.dsc_oferta_normalizada is 'Descrição da oferta usada pelo cliente em D-2';
comment on column reports.dw_r_recarga_oferta_hist.vlr_recarga            is 'Soma do valor de recarga.';
comment on column reports.dw_r_recarga_oferta_hist.qtd_recarga            is 'Quantindade recarga';

create table reports.dw_r_recarga_oferta_dia
(
    dat_ref                 date                   ,
    num_hora                numeric                ,
    nom_regional_venda      character varying(100) ,
    num_cn                  character varying(10)  ,
    dsc_plano_normalizado   character varying(10)  ,
    dsc_valor_face          character varying(50)  ,
    nom_canal_venda         character varying(250) ,
    nom_fantasia            character varying(250) ,
    dsc_oferta_normalizada  character varying(50)  ,
    vlr_recarga             numeric                ,
    qtd_recarga             numeric                
)
WITH (APPENDONLY=true, COMPRESSLEVEL=6, ORIENTATION=column, COMPRESSTYPE=zlib, OIDS=FALSE) DISTRIBUTED RANDOMLY;

alter table reports.dw_r_recarga_oferta_dia owner to udbd_load;
grant select on table reports.dw_r_recarga_oferta_dia to sdx_bigdata;

comment on table reports.dw_r_recarga_oferta_dia is 'Tabela diária com dados da base de oferta de recargas';

comment on column reports.dw_r_recarga_oferta_dia.dat_ref                is 'Data referência da recarga';
comment on column reports.dw_r_recarga_oferta_dia.num_hora               is 'Hora da recarga';
comment on column reports.dw_r_recarga_oferta_dia.nom_regional_venda     is 'Descrição do regional de venda.';
comment on column reports.dw_r_recarga_oferta_dia.num_cn                 is 'Código de área nacional';
comment on column reports.dw_r_recarga_oferta_dia.dsc_plano_normalizado  is 'Descrição  do plano com agrupamento para recargar';
comment on column reports.dw_r_recarga_oferta_dia.dsc_valor_face         is 'Valor de face das recargas.';
comment on column reports.dw_r_recarga_oferta_dia.nom_canal_venda        is 'Descrição do canal de venda.';
comment on column reports.dw_r_recarga_oferta_dia.nom_fantasia           is 'Nome fantasia.';
comment on column reports.dw_r_recarga_oferta_dia.dsc_oferta_normalizada is 'Descrição da oferta usada pelo cliente em D-2';
comment on column reports.dw_r_recarga_oferta_dia.vlr_recarga            is 'Soma do valor de recarga.';
comment on column reports.dw_r_recarga_oferta_dia.qtd_recarga            is 'Quantindade recarga';

create external table ext.dw_r_recarga_oferta_relatorio_dia
(
    dat_ref                 date                   ,
    dat_equiv_m1            date                   ,
    dat_equiv_m2            date                   ,
    dat_equiv_m3            date                   ,
    dat_equiv_m4            date                   ,
    num_hora                numeric                ,
    nom_regional_venda      character varying(100) ,
    num_cn                  character varying(10)  ,
    dsc_plano_normalizado   character varying(10)  ,
    dsc_valor_face          character varying(50)  ,
    nom_canal_venda         character varying(250) ,
    nom_fantasia            character varying(250) ,
    dsc_oferta_normalizada  character varying(50)  ,
    vlr_recarga_dia         numeric                ,
    qtd_recarga_dia         numeric                ,
    vlr_recarga_m1          numeric                ,
    qtd_recarga_m1          numeric                ,
    vlr_recarga_m2          numeric                ,
    qtd_recarga_m2          numeric                ,
    vlr_recarga_m3          numeric                ,
    qtd_recarga_m3          numeric                ,
    vlr_recarga_m4          numeric                ,
    qtd_recarga_m4          numeric                
)
location ('gphdfs://dcaisilon.timbrasil.com.br/platinum/work/recarga_detalhada/relatorio_diario/gpdb_staging/*')
format 'text' (delimiter '|' null '' escape 'off') encoding 'utf8';

alter table ext.dw_r_recarga_oferta_relatorio_dia owner to udbd_load;

create external table ext.dw_r_recarga_oferta_relatorio_hist
(
    dat_ref                 date                   ,
    dat_equiv_m1            date                   ,
    dat_equiv_m2            date                   ,
    dat_equiv_m3            date                   ,
    dat_equiv_m4            date                   ,
    num_hora                numeric                ,
    nom_regional_venda      character varying(100) ,
    num_cn                  character varying(10)  ,
    dsc_plano_normalizado   character varying(10)  ,
    dsc_valor_face          character varying(50)  ,
    nom_canal_venda         character varying(250) ,
    nom_fantasia            character varying(250) ,
    dsc_oferta_normalizada  character varying(50)  ,
    vlr_recarga_dia         numeric                ,
    qtd_recarga_dia         numeric                ,
    vlr_recarga_m1          numeric                ,
    qtd_recarga_m1          numeric                ,
    vlr_recarga_m2          numeric                ,
    qtd_recarga_m2          numeric                ,
    vlr_recarga_m3          numeric                ,
    qtd_recarga_m3          numeric                ,
    vlr_recarga_m4          numeric                ,
    qtd_recarga_m4          numeric                
)
location ('gphdfs://dcaisilon.timbrasil.com.br/platinum/work/recarga_detalhada/relatorio_historico/gpdb_staging/*')
format 'text' (delimiter '|' null '' escape 'off') encoding 'utf8';

alter table ext.dw_r_recarga_oferta_relatorio_hist owner to udbd_Load;

create table reports.dw_r_recarga_oferta_relatorio_hist
(
    dat_ref                 date                   ,
    dat_equiv_m1            date                   ,
    dat_equiv_m2            date                   ,
    dat_equiv_m3            date                   ,
    dat_equiv_m4            date                   ,
    num_hora                numeric                ,
    nom_regional_venda      character varying(100) ,
    num_cn                  character varying(10)  ,
    dsc_plano_normalizado   character varying(10)  ,
    dsc_valor_face          character varying(50)  ,
    nom_canal_venda         character varying(250) ,
    nom_fantasia            character varying(250) ,
    dsc_oferta_normalizada  character varying(50)  ,
    vlr_recarga_dia         numeric                ,
    qtd_recarga_dia         numeric                ,
    vlr_recarga_m1          numeric                ,
    qtd_recarga_m1          numeric                ,
    vlr_recarga_m2          numeric                ,
    qtd_recarga_m2          numeric                ,
    vlr_recarga_m3          numeric                ,
    qtd_recarga_m3          numeric                ,
    vlr_recarga_m4          numeric                ,
    qtd_recarga_m4          numeric                
)
WITH (APPENDONLY=true, COMPRESSLEVEL=6, ORIENTATION=row, COMPRESSTYPE=zlib, OIDS=FALSE) DISTRIBUTED RANDOMLY
PARTITION BY RANGE(dat_ref) (
start (date '2019-06-01'::date) inclusive end (date '2019-10-26'::date) exclusive every (interval '1 day'),
default partition outlying_days  WITH (APPENDONLY=true, COMPRESSLEVEL=6, ORIENTATION=row, COMPRESSTYPE=zlib, OIDS=FALSE));

alter table reports.dw_r_recarga_oferta_relatorio_hist owner to udbd_load;
grant select on table reports.dw_r_recarga_oferta_relatorio_hist to sdx_bigdata;

comment on table reports.dw_r_recarga_oferta_relatorio_hist  is 'Tabela com dados da base de recarga nos dias equivalentes, com as datas de equivalências m1,m2,m3,m4 agrupando o somatório do valor de recarga.
Essa tabela deverá ter 8 dias de recarga – dia atual  INTRA DAY  e mais 7 dias, buscando dados de equivalentes de m1, m2, m3 e m4.';

comment on column reports.dw_r_recarga_oferta_relatorio_hist.dat_ref                is 'Data referência da recarga';
comment on column reports.dw_r_recarga_oferta_relatorio_hist.dat_equiv_m1           is 'Data equivalente do mês anterior 1';
comment on column reports.dw_r_recarga_oferta_relatorio_hist.dat_equiv_m2           is 'Data equivalente do mês anterior 2';
comment on column reports.dw_r_recarga_oferta_relatorio_hist.dat_equiv_m3           is 'Data equivalente do mês anterior 3';
comment on column reports.dw_r_recarga_oferta_relatorio_hist.dat_equiv_m4           is 'Data equivalente do mês anterior 4';
comment on column reports.dw_r_recarga_oferta_relatorio_hist.num_hora               is 'Hora da recarga';
comment on column reports.dw_r_recarga_oferta_relatorio_hist.nom_regional_venda     is 'Descrição do regional de venda.';
comment on column reports.dw_r_recarga_oferta_relatorio_hist.num_cn                 is 'Código de área nacional';
comment on column reports.dw_r_recarga_oferta_relatorio_hist.dsc_plano_normalizado  is 'Descrição  do plano com agrupamento para recargar';
comment on column reports.dw_r_recarga_oferta_relatorio_hist.dsc_valor_face         is 'Valor de face das recargas.';
comment on column reports.dw_r_recarga_oferta_relatorio_hist.nom_canal_venda        is 'Descrição do canal de venda.';
comment on column reports.dw_r_recarga_oferta_relatorio_hist.nom_fantasia           is 'Nome fantasia.';
comment on column reports.dw_r_recarga_oferta_relatorio_hist.dsc_oferta_normalizada is 'Descrição da oferta usada pelo cliente em D-2';
comment on column reports.dw_r_recarga_oferta_relatorio_hist.vlr_recarga_dia        is 'Soma do valor de recargar';
comment on column reports.dw_r_recarga_oferta_relatorio_hist.qtd_recarga_dia        is 'Quantindade recarga dia';
comment on column reports.dw_r_recarga_oferta_relatorio_hist.vlr_recarga_m1         is 'Soma do valor de recargar do dia equivalente m1';
comment on column reports.dw_r_recarga_oferta_relatorio_hist.qtd_recarga_m1         is 'Quantindade recarga do dia equivalente m1';
comment on column reports.dw_r_recarga_oferta_relatorio_hist.vlr_recarga_m2         is 'Soma do valor de recargar do dia equivalente m2';
comment on column reports.dw_r_recarga_oferta_relatorio_hist.qtd_recarga_m2         is 'Quantindade recarga do dia equivalente m2';
comment on column reports.dw_r_recarga_oferta_relatorio_hist.vlr_recarga_m3         is 'Soma do valor de recargar do dia equivalente m3';
comment on column reports.dw_r_recarga_oferta_relatorio_hist.qtd_recarga_m3         is 'Quantindade recarga do dia equivalente m3';
comment on column reports.dw_r_recarga_oferta_relatorio_hist.vlr_recarga_m4         is 'Soma do valor de recargar do dia equivalente m4';
comment on column reports.dw_r_recarga_oferta_relatorio_hist.qtd_recarga_m4         is 'Quantindade recarga do dia equivalente m4';

create table reports.dw_r_recarga_oferta_relatorio_dia
(
    dat_ref                 date                   ,
    dat_equiv_m1            date                   ,
    dat_equiv_m2            date                   ,
    dat_equiv_m3            date                   ,
    dat_equiv_m4            date                   ,
    num_hora                numeric                ,
    nom_regional_venda      character varying(100) ,
    num_cn                  character varying(10)  ,
    dsc_plano_normalizado   character varying(10)  ,
    dsc_valor_face          character varying(50)  ,
    nom_canal_venda         character varying(250) ,
    nom_fantasia            character varying(250) ,
    dsc_oferta_normalizada  character varying(50)  ,
    vlr_recarga_dia         numeric                ,
    qtd_recarga_dia         numeric                ,
    vlr_recarga_m1          numeric                ,
    qtd_recarga_m1          numeric                ,
    vlr_recarga_m2          numeric                ,
    qtd_recarga_m2          numeric                ,
    vlr_recarga_m3          numeric                ,
    qtd_recarga_m3          numeric                ,
    vlr_recarga_m4          numeric                ,
    qtd_recarga_m4          numeric                
)
WITH (APPENDONLY=true, COMPRESSLEVEL=6, ORIENTATION=column, COMPRESSTYPE=zlib, OIDS=FALSE) DISTRIBUTED RANDOMLY;

alter table reports.dw_r_recarga_oferta_relatorio_dia owner to udbd_load;
grant select on table reports.dw_r_recarga_oferta_relatorio_dia to sdx_bigdata;

comment on table reports.dw_r_recarga_oferta_relatorio_dia  is 'Tabela com dados da base de recarga nos dias equivalentes, com as datas de equivalências m1,m2,m3,m4 agrupando o somatório do valor de recarga. Esta tabela contem 1 dia.';

comment on column reports.dw_r_recarga_oferta_relatorio_dia.dat_ref                is 'Data referência da recarga';
comment on column reports.dw_r_recarga_oferta_relatorio_dia.dat_equiv_m1           is 'Data equivalente do mês anterior 1';
comment on column reports.dw_r_recarga_oferta_relatorio_dia.dat_equiv_m2           is 'Data equivalente do mês anterior 2';
comment on column reports.dw_r_recarga_oferta_relatorio_dia.dat_equiv_m3           is 'Data equivalente do mês anterior 3';
comment on column reports.dw_r_recarga_oferta_relatorio_dia.dat_equiv_m4           is 'Data equivalente do mês anterior 4';
comment on column reports.dw_r_recarga_oferta_relatorio_dia.num_hora               is 'Hora da recarga';
comment on column reports.dw_r_recarga_oferta_relatorio_dia.nom_regional_venda     is 'Descrição do regional de venda.';
comment on column reports.dw_r_recarga_oferta_relatorio_dia.num_cn                 is 'Código de área nacional';
comment on column reports.dw_r_recarga_oferta_relatorio_dia.dsc_plano_normalizado  is 'Descrição  do plano com agrupamento para recargar';
comment on column reports.dw_r_recarga_oferta_relatorio_dia.dsc_valor_face         is 'Valor de face das recargas.';
comment on column reports.dw_r_recarga_oferta_relatorio_dia.nom_canal_venda        is 'Descrição do canal de venda.';
comment on column reports.dw_r_recarga_oferta_relatorio_dia.nom_fantasia           is 'Nome fantasia.';
comment on column reports.dw_r_recarga_oferta_relatorio_dia.dsc_oferta_normalizada is 'Descrição da oferta usada pelo cliente em D-2';
comment on column reports.dw_r_recarga_oferta_relatorio_dia.vlr_recarga_dia        is 'Soma do valor de recargar';
comment on column reports.dw_r_recarga_oferta_relatorio_dia.qtd_recarga_dia        is 'Quantindade recarga dia';
comment on column reports.dw_r_recarga_oferta_relatorio_dia.vlr_recarga_m1         is 'Soma do valor de recargar do dia equivalente m1';
comment on column reports.dw_r_recarga_oferta_relatorio_dia.qtd_recarga_m1         is 'Quantindade recarga do dia equivalente m1';
comment on column reports.dw_r_recarga_oferta_relatorio_dia.vlr_recarga_m2         is 'Soma do valor de recargar do dia equivalente m2';
comment on column reports.dw_r_recarga_oferta_relatorio_dia.qtd_recarga_m2         is 'Quantindade recarga do dia equivalente m2';
comment on column reports.dw_r_recarga_oferta_relatorio_dia.vlr_recarga_m3         is 'Soma do valor de recargar do dia equivalente m3';
comment on column reports.dw_r_recarga_oferta_relatorio_dia.qtd_recarga_m3         is 'Quantindade recarga do dia equivalente m3';
comment on column reports.dw_r_recarga_oferta_relatorio_dia.vlr_recarga_m4         is 'Soma do valor de recargar do dia equivalente m4';
comment on column reports.dw_r_recarga_oferta_relatorio_dia.qtd_recarga_m4         is 'Quantindade recarga do dia equivalente m4';

-- CRIAÇÃO DA VIEW reports.vw_r_recarga_oferta
create or replace view reports.vw_r_recarga_oferta
as
SELECT 
dat_ref
,num_hora
,nom_regional_venda
,num_cn
,dsc_plano_normalizado
,dsc_valor_face
,nom_canal_venda
,nom_fantasia
,dsc_oferta_normalizada
,vlr_recarga
,qtd_recarga
FROM 
reports.dw_r_recarga_oferta_dia
union all
SELECT 
dat_ref
,num_hora
,nom_regional_venda
,num_cn
,dsc_plano_normalizado
,dsc_valor_face
,nom_canal_venda
,nom_fantasia
,dsc_oferta_normalizada
,vlr_recarga
,qtd_recarga
FROM 
reports.dw_r_recarga_oferta_hist;

alter table reports.vw_r_recarga_oferta owner to udbd_load;
grant select on table reports.vw_r_recarga_oferta to sdx_bigdata;

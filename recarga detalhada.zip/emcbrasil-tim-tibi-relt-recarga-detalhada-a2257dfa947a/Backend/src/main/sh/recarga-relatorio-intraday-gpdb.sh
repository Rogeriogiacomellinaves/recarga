#!/bin/bash

source /data/apps/env/setup.sh

CONFIG="$HOME/resources/gpdb/recarga_relatorio_intraday_gpdb_configuration.xml"
LOG=file:$HOME/resources/gpdb_log4j.properties
SYSTEM_PROPERTIES=$SYSTEM_PROPERTIES" -Dconfiguration=$CONFIG"

java $JAVA_OPTS $SYSTEM_PROPERTIES -cp $CM_CLASSPATH br.com.tim.gpdb.GpdbIngestion
		
if [ $? -ne 0 ]
	then
	exit 1
fi


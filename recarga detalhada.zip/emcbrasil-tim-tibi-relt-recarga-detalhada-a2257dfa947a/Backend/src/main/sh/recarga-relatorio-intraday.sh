#!/bin/bash

source /data/apps/env/setup.sh

for file in `ls ${HOME}/jars/`
do
PATH_JAR="${HOME}/jars/$file"
done

CONFIG="$HOME/resources/intraday/recarga_relatorio_intraday_configuration.xml"
SYSTEM_PROPERTIES=$SYSTEM_PROPERTIES" -Dconfiguration=$CONFIG -Dpath.jar=$PATH_JAR"

java $JAVA_OPTS $SYSTEM_PROPERTIES -cp $CM_CLASSPATH br.com.tim.hive.query.HiveQueryDriver

EXIT_CODE=$?

exit $EXIT_CODE
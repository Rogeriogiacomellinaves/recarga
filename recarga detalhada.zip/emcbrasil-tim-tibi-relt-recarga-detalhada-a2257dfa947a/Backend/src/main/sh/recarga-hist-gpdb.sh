#!/bin/bash

source /data/apps/env/setup.sh

CONFIG="$HOME/resources/gpdb/recarga_hist_gpdb_configuration.xml"
SYSTEM_PROPERTIES=$SYSTEM_PROPERTIES" -Dconfiguration=$CONFIG"

java $JAVA_OPTS $SYSTEM_PROPERTIES -cp $CM_CLASSPATH br.com.tim.gpdb.GpdbIngestion
		
if [ $? -ne 0 ]
	then
	exit 1
fi

